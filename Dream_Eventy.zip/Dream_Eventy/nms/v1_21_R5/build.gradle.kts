dependencies {
    compileOnly(project(":plugin-core:nms:api"))

    paperweight.paperDevBundle("1.21.8-R0.1-SNAPSHOT")
}
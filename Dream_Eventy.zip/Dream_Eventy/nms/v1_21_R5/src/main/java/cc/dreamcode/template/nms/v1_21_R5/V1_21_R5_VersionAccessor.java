package cc.dreamcode.template.nms.v1_21_R5;

import cc.dreamcode.template.nms.api.VersionAccessor;

public class V1_21_R5_VersionAccessor implements VersionAccessor {

}

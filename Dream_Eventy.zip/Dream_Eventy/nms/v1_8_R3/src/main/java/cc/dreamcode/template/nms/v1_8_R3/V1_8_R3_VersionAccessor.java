package cc.dreamcode.template.nms.v1_8_R3;

import cc.dreamcode.template.nms.api.VersionAccessor;

public class V1_8_R3_VersionAccessor implements VersionAccessor {

}
